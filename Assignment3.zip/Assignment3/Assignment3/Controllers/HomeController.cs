﻿using Assignment3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
//This controller connects the pages, so pages load and so the form can connect to the film list
namespace Assignment3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Podcast()
        {
            return View();
        }
        //connects to the form to fill out
        [HttpGet]
        public IActionResult Form()
        {
            return View();
        }
        //connects to the confirmation page if the form was filled out correctly. Otherwise stays on the form
        [HttpPost]
        public IActionResult Form(ApplicationResponse AppResponse)
        {
            if (ModelState.IsValid)
            {
                FilmList.AddApplication(AppResponse);
                return View("Confirmation", AppResponse);
            }
                return View();
        }
        //connects to the list page, bringing the list of movies from the form page with it
        public IActionResult List()
        {
            return View(FilmList.Applications);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
