﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//this code helps handle the film data, so it can be used throughout the website
namespace Assignment3.Models
{
    public class FilmList
    {
        private static List<ApplicationResponse> applications = new List<ApplicationResponse>();

        public static IEnumerable<ApplicationResponse> Applications => applications;

        public static void AddApplication(ApplicationResponse application)
        {
            applications.Add(application);
        }
    }
}
